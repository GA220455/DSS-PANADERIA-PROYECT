<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    http_response_code(403);
    echo json_encode(["error" => "No autorizado"]);
    exit;
}

require 'clases/ventas.php';

$conexion = new mysqli('localhost', 'root', '', 'inventario');
$venta = new Venta($conexion);

// Leer datos desde JSON
$data = json_decode(file_get_contents("php://input"), true);

if (!$data || empty($data['productos'])) {
    http_response_code(400);
    echo json_encode(["error" => "Datos incompletos"]);
    exit;
}

// Registrar venta
$venta_id = $venta->registrarVenta($data['productos']);

if ($venta_id) {
    echo json_encode(["success" => true, "venta_id" => $venta_id]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "No se pudo registrar la venta"]);
}
?>
