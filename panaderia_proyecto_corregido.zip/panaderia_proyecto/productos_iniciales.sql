USE inventario;

INSERT INTO productos (nombre, precio) VALUES
('Bidón grande', 39.00),
('Medio Bidón', 21.00),
('Caja de jalea', 21.00),
('Caja de jalea provapan', 21.00),
('Azucar', 50.50),
('Harina de espiga fuerte', 21),
('Harina de espiga suave', 21.50),
('Harina de espiga semi fuerte', 22),
('Harina fortaleza', 21.50),
('Harina west', 20.50),
('Molsa semi fuerte', 23),
('Molsa suave', 21.50)

