<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Confirmar Venta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f3e8; }
        .btn-confirmar { background-color: #d2a679; color: white; }
        .btn-confirmar:hover { background-color: #28a745; }
    </style>
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>🧾 Confirmar Venta</h4>
        <a href="productos.php" class="btn btn-dark btn-sm">Volver</a>
    </div>

    <div id="resumen"></div>

    <div class="text-end mt-4">
        <button class="btn btn-confirmar px-4" onclick="confirmarVenta()">Finalizar Compra</button>
    </div>

    <div id="mensaje" class="mt-3 text-success fw-bold"></div>
</div>

<script>
const carrito = JSON.parse(localStorage.getItem("carrito")) || [];

function renderResumen() {
    if (carrito.length === 0) {
        document.getElementById("resumen").innerHTML = "<p class='text-muted'>No hay productos para facturar.</p>";
        return;
    }

    let html = "<table class='table table-bordered'>";
    html += "<thead class='table-light'><tr><th>#</th><th>Producto</th><th>Presentación</th><th>Cantidad</th><th>Precio</th><th>Subtotal</th></tr></thead><tbody>";

    let total = 0;
    carrito.forEach((item, i) => {
        const subtotal = item.precio * item.cantidad;
        total += subtotal;
        html += `<tr>
                    <td>${i + 1}</td>
                    <td>${item.producto}</td>
                    <td>${item.presentacion}</td>
                    <td>${item.cantidad}</td>
                    <td>$${item.precio.toFixed(2)}</td>
                    <td>$${subtotal.toFixed(2)}</td>
                </tr>`;
    });

    html += `</tbody></table><div class='text-end fw-bold fs-5'>Total: $${total.toFixed(2)}</div>`;
    document.getElementById("resumen").innerHTML = html;
}

function confirmarVenta() {
    fetch("guardar_venta.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productos: carrito })
    })
    .then(res => res.json())
    .then(res => {
        if (res.success) {
            document.getElementById("mensaje").innerText = "✅ Factura registrada con éxito (Ticket #" + res.venta_id + ")";
            localStorage.removeItem("carrito");
            renderResumen();
        } else {
            alert("Error al guardar la venta.");
        }
    })
    .catch(() => alert("Error al conectar con el servidor."));
}

renderResumen();
</script>
</body>
</html>
