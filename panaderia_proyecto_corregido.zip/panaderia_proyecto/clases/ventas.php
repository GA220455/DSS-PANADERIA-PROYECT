<?php
class Venta {
    private $conn;

    public function __construct($conexion) {
        $this->conn = $conexion;
    }

    public function registrarVenta($productos, $impuesto = 0.21) {
        $this->conn->begin_transaction();
        try {
            $sql = "INSERT INTO ventas (fecha) VALUES (NOW())";
            $this->conn->query($sql);
            $venta_id = $this->conn->insert_id;
            $total = 0;

            foreach ($productos as $item) {
                $subtotal = $item['cantidad'] * $item['precio_unitario'];
                $total += $subtotal;

                $sql = "INSERT INTO venta_detalle (venta_id, producto_id, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
                $stmt = $this->conn->prepare($sql);
                $stmt->bind_param("iiid", $venta_id, $item['producto_id'], $item['cantidad'], $item['precio_unitario']);
                $stmt->execute();
            }

            $total_con_impuesto = $total * (1 + $impuesto);
            $this->conn->query("UPDATE ventas SET total = $total_con_impuesto WHERE id = $venta_id");

            $this->conn->commit();
            return $venta_id;
        } catch (Exception $e) {
            $this->conn->rollback();
            return false;
        }
    }

    public function obtenerVentas() {
        $ventas = [];

        $resultado = $this->conn->query("SELECT id, fecha, total FROM ventas ORDER BY fecha DESC");

        while ($venta = $resultado->fetch_assoc()) {
            $venta_id = $venta['id'];
            $detalles = [];

            $resDetalles = $this->conn->query("
                SELECT p.nombre, d.cantidad, d.precio_unitario, (d.cantidad * d.precio_unitario) AS subtotal
                FROM venta_detalle d
                JOIN productos p ON d.producto_id = p.id
                WHERE d.venta_id = $venta_id
            ");

            while ($detalle = $resDetalles->fetch_assoc()) {
                $detalles[] = $detalle;
            }

            $venta['detalles'] = $detalles;
            $ventas[] = $venta;
        }

        return $ventas;
    }
}
?>

