<?php
class Producto {
    private $conn;
    public function __construct($conexion) {
        $this->conn = $conexion;
    }
    public function agregarProducto($nombre, $stock, $precio) {
        $sql = "INSERT INTO productos (nombre, stock, precio) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sii", $nombre, $stock, $precio);
        return $stmt->execute();
    }
    public function actualizarStock($producto_id, $nuevo_stock) {
        $sql = "UPDATE productos SET stock = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ii", $nuevo_stock, $producto_id);
        return $stmt->execute();
    }
    public function obtenerProductos() {
        $result = $this->conn->query("SELECT * FROM productos");
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}
?>
