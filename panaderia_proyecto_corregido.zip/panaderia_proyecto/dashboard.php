<?php 
session_start(); 
if (!isset($_SESSION['usuario'])) header('Location: login.php'); 
$rol = $_SESSION['usuario']['rol']; 
$username = $_SESSION['usuario']['username'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Principal - Panadería</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f3e8;
        }
        .navbar {
            background-color: #deb887; /* color pan tostado */
        }
        .navbar-brand {
            font-weight: bold;
        }
        .card {
            background-color: #fffaf2;
            border: 1px solid #e0d3b8;
        }
        .btn-custom {
            background-color: #d2a679;
            color: white;
        }
        .btn-custom:hover {
            background-color: #bf8c4c;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light px-4">
        <a class="navbar-brand" href="#">🥖 Panadería</a>
        <div class="ms-auto">
            <span class="me-3 text-dark">Bienvenido, <strong><?= htmlspecialchars($username) ?></strong></span>
            <a class="btn btn-sm btn-dark" href="logout.php">Cerrar Sesión</a>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row g-4 justify-content-center">
            <div class="col-md-4">
                <div class="card text-center shadow">
                    <div class="card-body">
                        <h5 class="card-title">Gestión de Productos</h5>
                        <p class="card-text">Consulta y administra tu inventario.</p>
                        <a href="productos.php" class="btn btn-custom">Ver Productos</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center shadow">
                    <div class="card-body">
                        <h5 class="card-title">Nueva Venta</h5>
                        <p class="card-text">Registra una venta al instante.</p>
                        <a href="venta_nueva.php" class="btn btn-custom">Registrar Venta</a>
                    </div>
                </div>
            </div>
            <?php if ($rol === 'admin'): ?>
            <div class="col-md-4">
                <div class="card text-center shadow">
                    <div class="card-body">
                        <h5 class="card-title">Reportes</h5>
                        <p class="card-text">Consulta el historial de ventas.</p>
                        <a href="reporte_ventas.php" class="btn btn-custom">Ver Reportes</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
