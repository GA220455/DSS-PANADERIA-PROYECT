<?php 
session_start(); 
require 'clases/usuarios.php'; 
if(!isset($_SESSION['usuario'])) header('Location: login.php'); 
$usuario = new Usuario(new mysqli('db','root','root','inventario')); 
if (!$usuario->esAdmin()) die('Acceso denegado');

$conexion = new mysqli('db','root','root','inventario'); 
$resultado = $conexion->query("SELECT * FROM ventas");
?>
<h2>Reporte de Ventas</h2>
<table border='1'>
    <tr><th>ID</th><th>Fecha</th><th>Total</th></tr>
    <?php while($v = $resultado->fetch_assoc()): ?>
        <tr>
            <td><?= $v['id'] ?></td>
            <td><?= $v['fecha'] ?></td>
            <td>$<?= $v['total'] ?></td>
        </tr>
    <?php endwhile; ?>
</table>
<a href='dashboard.php'>Volver</a>
