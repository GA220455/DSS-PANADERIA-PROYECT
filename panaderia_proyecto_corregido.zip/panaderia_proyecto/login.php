<?php 
session_start(); 
if ($_SERVER['REQUEST_METHOD'] === 'POST') { 
    require 'clases/usuarios.php'; 
    $conexion = new mysqli('localhost', 'root', '', 'inventario');
    $usuario = new Usuario($conexion); 
    if ($usuario->login($_POST['username'], $_POST['password'])) { 
        header('Location: dashboard.php'); 
        exit(); 
    } else { 
        $error = 'Usuario o contraseña incorrectos.'; 
    } 
} 
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login - Panadería</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f3e8;
        }
        .card {
            background-color: #fffaf2;
            border: 1px solid #e0d3b8;
        }
        .btn-custom {
            background-color: #d2a679;
            color: white;
        }
        .btn-custom:hover {
            background-color: #bf8c4c;
        }
    </style>
</head>
<body class="d-flex align-items-center justify-content-center" style="min-height: 100vh;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card shadow rounded-4 p-4">
                    <h3 class="text-center mb-4">Iniciar Sesión</h3>
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger text-center"><?= $error ?></div>
                    <?php endif; ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Usuario</label>
                            <input name="username" class="form-control" placeholder="Usuario" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Contraseña</label>
                            <input name="password" type="password" class="form-control" placeholder="Contraseña" required>
                        </div>
                        <button class="btn btn-custom w-100">Ingresar</button>
                    </form>
                </div>
                <p class="text-center mt-4 text-muted">🥖 Sistema de Inventario - Panadería</p>
            </div>
        </div>
    </div>
</body>
</html>
