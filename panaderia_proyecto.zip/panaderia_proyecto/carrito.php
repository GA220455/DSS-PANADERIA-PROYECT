<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Carrito de Compras</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f3e8;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .btn-finalizar {
            background-color: #d2a679;
            color: white;
            transition: background-color 0.3s;
        }
        .btn-finalizar:hover {
            background-color: #28a745;
        }
    </style>
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>🛒 Carrito de Compras</h4>
        <div>
            <a href="productos.php" class="btn btn-dark btn-sm me-2">Seguir Comprando</a>
            <button class="btn btn-danger btn-sm" onclick="vaciarCarrito()">Vaciar Carrito</button>
        </div>
    </div>
    <div id="carrito-container"></div>
</div>

<script>
    const precios = {
        'Harina de espiga fuerte': {quintal: 23.25, medio: 6.00, arroba: 11.90},
        'Harina de espiga suave': {quintal: 21.25, medio: 5.50, arroba: 10.90},
        'Harina de espiga semi fuerte': {quintal: 22.50, medio: 5.75, arroba: 11.50},
        'Harina fortaleza': {quintal: 22.50, medio: 5.75, arroba: 11.50},
        'Harina west': {quintal: 20.75, medio: 5.40, arroba: 11.20},
        'Molsa semi fuerte': {quintal: 23.00, medio: 6.00, arroba: 11.75},
        'Molsa suave': {quintal: 21.50, medio: 5.55, arroba: 11.00},
        'Azucar': {quintal: 50.50, medio: 25.00, arroba: 12.35},
        'default': {única: 5.00}
    };

    function mostrarCarrito() {
        const carrito = JSON.parse(localStorage.getItem("carrito")) || [];

        if (carrito.length === 0) {
            document.getElementById("carrito-container").innerHTML = "<p class='text-muted'>No hay productos en el carrito.</p>";
            return;
        }

        let html = "<table class='table table-bordered table-striped'>";
        html += "<thead class='table-light'><tr><th>#</th><th>Producto</th><th>Presentación</th><th>Cantidad</th><th>Precio Unitario</th><th>Subtotal</th><th>Acciones</th></tr></thead><tbody>";

        let total = 0;

        carrito.forEach((item, index) => {
            const producto = item.producto;
            const tipo = item.presentacion.toLowerCase();
            const cantidad = item.cantidad;

            let precio = item.precio ?? (precios[producto]?.[tipo] ?? precios['default'].única);
            let subtotal = precio * cantidad;
            total += subtotal;

            html += `<tr>
                        <td>${index + 1}</td>
                        <td>${producto}</td>
                        <td>${item.presentacion}</td>
                        <td>${cantidad}</td>
                        <td>$${precio.toFixed(2)}</td>
                        <td>$${subtotal.toFixed(2)}</td>
                        <td><button class='btn btn-sm btn-danger' onclick='eliminarItem(${index})'>Eliminar</button></td>
                    </tr>`;
        });

        html += `</tbody></table>
                 <div class='text-end fw-bold mb-3'>Total a pagar: $${total.toFixed(2)}</div>
                 <div class='text-end'>
                    <a href="facturacion.php" class="btn btn-finalizar">Finalizar Compra</a>
                 </div>`;

        document.getElementById("carrito-container").innerHTML = html;
    }

    function eliminarItem(index) {
        const carrito = JSON.parse(localStorage.getItem("carrito")) || [];
        carrito.splice(index, 1);
        localStorage.setItem("carrito", JSON.stringify(carrito));
        mostrarCarrito();
    }

    function vaciarCarrito() {
        if (confirm("¿Estás seguro de que deseas vaciar el carrito?")) {
            localStorage.removeItem("carrito");
            mostrarCarrito();
        }
    }

    mostrarCarrito();
</script>
</body>
</html>

