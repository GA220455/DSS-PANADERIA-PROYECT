<?php
class Usuario {
    private $conn;
    public function __construct($conexion) {
        $this->conn = $conexion;
    }
    public function registrar($username, $password, $rol) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO usuarios (username, password, rol) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sss", $username, $hash, $rol);
        return $stmt->execute();
    }
    public function login($username, $password) {
        $sql = "SELECT * FROM usuarios WHERE username = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $usuario = $stmt->get_result()->fetch_assoc();
        if ($usuario && password_verify($password, $usuario['password'])) {
            session_start();
            $_SESSION['usuario'] = $usuario;
            return true;
        }
        return false;
    }
    public function esAdmin() {
        session_start();
        return $_SESSION['usuario']['rol'] === 'admin';
    }
}
?>
