<?php
session_start();
if (!isset($_SESSION['usuario'])) header('Location: login.php');

$conexion = new mysqli('localhost', 'root', '', 'inventario');
$resultado = $conexion->query("SELECT * FROM productos");

$imagenes = [
    'Bidón grande' => 'imagenes/bidon_grande.jpg.jpeg',
    'Medio Bidón' => 'imagenes/medio_bidon.jpg.jpeg',
    'Caja de jalea' => 'imagenes/jalea.jpg.jpeg',
    'Caja de jalea provapan' => 'imagenes/jalea_provapan.jpg.jpeg',
    'Medio quintal de 5lb' => 'imagenes/azucar_medio_quintal.jpg.jpeg',
    'Azucar' => 'imagenes/azucar.jpg.jpeg',
    'Harina de espiga fuerte' => 'imagenes/harina_fuerte.jpg.jpeg',
    'Harina de espiga suave' => 'imagenes/harina_suave.jpg.jpeg',
    'Harina de espiga semi fuerte' => 'imagenes/harina_semifuerte.jpg.jpeg',
    'Harina fortaleza' => 'imagenes/harina_fortaleza.jpg.jpeg',
    'Harina west' => 'imagenes/harina_west.jpg.jpeg',
    'Molsa semi fuerte' => 'imagenes/molsa_semifuerte.jpg.jpeg',
    'Molsa suave' => 'imagenes/molsa_suave.jpg.jpeg'
];

$preciosPresentacion = [
    'Harina de espiga fuerte' => ['quintal' => 23.25, 'medio' => 6.00, 'arroba' => 11.90],
    'Harina de espiga suave' => ['quintal' => 21.25, 'medio' => 5.50, 'arroba' => 10.90],
    'Harina de espiga semi fuerte' => ['quintal' => 22.50, 'medio' => 5.75, 'arroba' => 11.50],
    'Harina fortaleza' => ['quintal' => 22.50, 'medio' => 5.75, 'arroba' => 11.50],
    'Harina west' => ['quintal' => 20.75, 'medio' => 5.40, 'arroba' => 11.20],
    'Molsa semi fuerte' => ['quintal' => 23.00, 'medio' => 6.00, 'arroba' => 11.75],
    'Molsa suave' => ['quintal' => 21.50, 'medio' => 5.55, 'arroba' => 11.00],
    'Azucar' => ['quintal' => 50.50, 'medio' => 25.00, 'arroba' => 12.35]
];

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Productos - Panadería</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f3e8;
        }
        .card {
            background-color: #fffaf2;
            border: 1px solid #e0d3b8;
        }
        .producto-img {
            height: 360px;
            object-fit: cover;
            border-bottom: 1px solid #e0d3b8;
        }
        .btn-unidad {
            margin: 2px 4px;
        }
        .btn-cancelar {
            margin-top: 5px;
            font-size: 0.8rem;
        }
        .btn-comprar {
            margin-top: 10px;
            background-color: #d2a679;
            color: white;
            transition: background-color 0.3s;
        }
        .btn-comprar:hover {
            background-color: #28a745;
        }
    </style>
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <a href="dashboard.php" class="btn btn-dark btn-sm">Volver</a>
        <h4>Productos</h4>
        <a href="carrito.php" class="btn btn-outline-dark position-relative">
            🛒
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="carrito-count">0</span>
        </a>
    </div>
    <div class="row g-3">
        <?php while ($producto = $resultado->fetch_assoc()): ?>
            <?php 
                $nombre = $producto['nombre'];
                $precio = $producto['precio'];
                $id = md5($nombre);
                $imagen = $imagenes[$nombre] ?? 'imagenes/default.jpg';
                $esHarinaOMolsa = stripos($nombre, 'harina') !== false || stripos($nombre, 'molsa') !== false || stripos($nombre, 'azucar') !== false;
            ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="card shadow-sm h-100">
                    <img src="<?= $imagen ?>" class="card-img-top producto-img" alt="<?= htmlspecialchars($nombre) ?>">
                    <div class="card-body text-center">
                        <h5 class="card-title"><?= htmlspecialchars($nombre) ?></h5>
                        <p class="card-text">$<?= number_format($precio, 2) ?></p>
                        <input type="hidden" id="precio-<?= $id ?>" value="<?= $precio ?>">

                        <?php if ($esHarinaOMolsa): ?>
                            <div class="mb-2">
                                <button class="btn btn-sm btn-outline-secondary btn-unidad" onclick="incrementar('<?= $id ?>', 'quintal')">Quintal</button>
                                <button class="btn btn-sm btn-outline-secondary btn-unidad" onclick="incrementar('<?= $id ?>', 'medio')">Medio Quintal</button>
                                <button class="btn btn-sm btn-outline-secondary btn-unidad" onclick="incrementar('<?= $id ?>', 'arroba')">Arroba</button>
                                <button class="btn btn-sm btn-outline-danger btn-cancelar" onclick="cancelar('<?= $id ?>')">Cancelar</button>
                            </div>
                            <ul class="list-unstyled small text-muted mb-2">
    <li>Quintal: $<?= number_format($preciosPresentacion[$nombre]['quintal'] ?? 0, 2) ?></li>
    <li>Medio Quintal: $<?= number_format($preciosPresentacion[$nombre]['medio'] ?? 0, 2) ?></li>
    <li>Arroba: $<?= number_format($preciosPresentacion[$nombre]['arroba'] ?? 0, 2) ?></li>
</ul>
<p class="card-text" id="contador-<?= $id ?>">Seleccionado: Ninguno</p>
                        <?php endif; ?>

                        <button class="btn btn-sm btn-comprar w-100" onclick="agregarAlCarrito('<?= $nombre ?>', '<?= $id ?>')">Comprar</button>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<script>
    const contadores = {};

    function incrementar(id, tipo) {
        contadores[id] = {
            tipo: tipo,
            cantidad: (contadores[id]?.tipo === tipo ? (contadores[id]?.cantidad || 0) + 1 : 1)
        };
        document.getElementById('contador-' + id).innerText = `Seleccionado: ${capitalizar(tipo)} - ${contadores[id].cantidad}`;
    }

    function cancelar(id) {
        delete contadores[id];
        document.getElementById('contador-' + id).innerText = "Seleccionado: Ninguno";
    }

    function capitalizar(texto) {
        return texto.charAt(0).toUpperCase() + texto.slice(1);
    }

    function agregarAlCarrito(nombre, id) {
        const item = contadores[id];
        const precio = parseFloat(document.getElementById('precio-' + id).value);

        let presentacion = "Única";
        let cantidad = 1;

        if (item && item.tipo && item.cantidad) {
            presentacion = capitalizar(item.tipo);
            cantidad = item.cantidad;
        } else if (document.getElementById('contador-' + id)) {
            alert("Por favor, selecciona una presentación antes de comprar.");
            return;
        }

        const carrito = JSON.parse(localStorage.getItem("carrito")) || [];
        carrito.push({
            producto: nombre,
            presentacion: presentacion,
            cantidad: cantidad,
            precio: precio
        });

        localStorage.setItem("carrito", JSON.stringify(carrito));
        alert("Producto agregado al carrito.");
        actualizarContadorCarrito();
    }

    function actualizarContadorCarrito() {
        const carrito = JSON.parse(localStorage.getItem("carrito")) || [];
        document.getElementById("carrito-count").innerText = carrito.length;
    }

    actualizarContadorCarrito();
</script>
</body>
</html>





