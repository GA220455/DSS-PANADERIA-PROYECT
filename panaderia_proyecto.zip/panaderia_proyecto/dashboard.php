<?php 
session_start(); 
if (!isset($_SESSION['usuario'])) header('Location: login.php'); 
$rol = $_SESSION['usuario']['rol']; 
$username = $_SESSION['usuario']['username'];
?>
<!DOCTYPE html>

<html lang="es">
<head>
<meta charset="utf-8"/>
<title>Panel Principal - Panadería</title>
<meta content="width=device-width, initial-scale=1" name="viewport"/>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
<style>
        body {
            background-color: #f8f3e8;
        }
        .navbar {
            background-color: #deb887;
        }
        .navbar-brand {
            font-weight: bold;
        }
        .card {
            background-color: #fffaf2;
            border: 1px solid #e0d3b8;
        }
        .btn-custom {
            background-color: #d2a679;
            color: white;
        }
        .btn-custom:hover {
            background-color: #bf8c4c;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light px-4">
<a class="navbar-brand" href="#">🥖 Panadería</a>
<div class="ms-auto">
<span class="me-3 text-dark">Bienvenido, <strong><?= htmlspecialchars($username) ?></strong></span>
<a class="btn btn-sm btn-dark" href="logout.php">Cerrar Sesión</a>
</div>
</nav>
<div class="container py-5">
<div class="row g-4 justify-content-center">
<div class="col-md-4">
<div class="card text-center shadow">
<div class="card-body">
<h5 class="card-title">Productos</h5>
<p class="card-text">Materiales para tu panadería</p>
<a class="btn btn-custom" href="productos.php">Ver Productos</a>
</div>
</div>
</div>
</div>
<div class="text-center mt-5">
<h5 class="text-secondary">Venta de harina y productos para su panadería y pastelería 🍞🎂</h5>
</div>
<div class="carousel slide mt-4" data-bs-ride="carousel" id="carouselPanaderia">
<div class="carousel-inner rounded shadow">
<div class="carousel-item active">
<img alt="Pan fresco" class="d-block w-100" src="imagenes/slider1.jpg" style="height: 420px; object-fit: contain; background-color: #f0e7da;"/>
</div>
<div class="carousel-item">
<img alt="Pastel decorado" class="d-block w-100" src="imagenes/slider2.jpg" style="height: 420px; object-fit: contain; background-color: #f0e7da;"/>
</div>
<div class="carousel-item">
<img alt="Harina en saco" class="d-block w-100" src="imagenes/slider3.jpg" style="height: 420px; object-fit: contain; background-color: #f0e7da;"/>
</div>
<div class="carousel-item">
<img alt="Ingredientes" class="d-block w-100" src="imagenes/slider4.jpg" style="height: 420px; object-fit: contain; background-color: #f0e7da;"/>
</div>
</div>
<button class="carousel-control-prev" data-bs-slide="prev" data-bs-target="#carouselPanaderia" type="button">
<span aria-hidden="true" class="carousel-control-prev-icon" style="background-color: #d2a679;"></span>
</button>
<button class="carousel-control-next" data-bs-slide="next" data-bs-target="#carouselPanaderia" type="button">
<span aria-hidden="true" class="carousel-control-next-icon" style="background-color: #d2a679;"></span>
</button>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>