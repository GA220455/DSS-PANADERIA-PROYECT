<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resumen de Facturación</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        body {
            background-color: #f8f3e8;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .btn-confirmar, .btn-descargar {
            background-color: #d2a679;
            color: white;
        }
        .btn-confirmar:hover, .btn-descargar:hover {
            background-color: #28a745;
        }
    </style>
</head>
<body>
<div class="container py-4" id="factura">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>🧾 Resumen de Facturación</h4>
        <a href="productos.php" class="btn btn-dark btn-sm">Nueva Compra</a>
    </div>

    <div id="factura-container"></div>

    <div class="mt-4 text-end">
        <button class="btn btn-descargar me-2" onclick="descargarFactura()">Descargar PDF</button>
        <button class="btn btn-confirmar" onclick="confirmarCompra()">Confirmar Factura</button>
    </div>
</div>

<script>
    const carrito = JSON.parse(localStorage.getItem("carrito")) || [];

    function mostrarFactura() {
        if (carrito.length === 0) {
            document.getElementById("factura-container").innerHTML = "<p class='text-muted'>No hay productos para facturar.</p>";
            return;
        }

        let html = "<table class='table table-bordered table-striped'>";
        html += "<thead class='table-light'><tr><th>#</th><th>Producto</th><th>Presentación</th><th>Cantidad</th><th>Precio Unitario</th><th>Subtotal</th></tr></thead><tbody>";

        let total = 0;

        carrito.forEach((item, index) => {
            const precio = item.precio ?? 0;
            const subtotal = precio * item.cantidad;
            total += subtotal;

            html += `<tr>
                        <td>${index + 1}</td>
                        <td>${item.producto}</td>
                        <td>${item.presentacion}</td>
                        <td>${item.cantidad}</td>
                        <td>$${precio.toFixed(2)}</td>
                        <td>$${subtotal.toFixed(2)}</td>
                    </tr>`;
        });

        html += `</tbody></table><div class='text-end fw-bold fs-5'>Total a pagar: $${total.toFixed(2)}</div>`;
        document.getElementById("factura-container").innerHTML = html;
    }

    function confirmarCompra() {
        alert("✅ Compra confirmada. ¡Gracias por su compra!");
        localStorage.removeItem("carrito");
        window.location.href = "productos.php";
    }

    function descargarFactura() {
        const element = document.getElementById("factura");
        const opt = {
            margin:       0.5,
            filename:     'factura.pdf',
            image:        { type: 'jpeg', quality: 0.98 },
            html2canvas:  { scale: 2 },
            jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
        };
        html2pdf().set(opt).from(element).save();
    }

    mostrarFactura();
</script>
</body>
</html>
